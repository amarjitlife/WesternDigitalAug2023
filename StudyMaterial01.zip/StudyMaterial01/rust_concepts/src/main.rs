// By default, Rust has a set of items defined in the 
// standard library that it brings into the
// scope of every program. This set is called the prelude

use std::io;
use std::cmp::Ordering;
use rand::Rng;

//_____________________________________________________

// Cargo understands Semantic
// Versioning (sometimes called SemVer), which is a 
// standard for writing version numbers. The
// number 0.8.3 is actually shorthand for ^0.8.3 , 
// which means any version that is at least
// 0.8.3 but below 0.9.0 .

// Cargo considers these versions to have public APIs 
// compatible with version 0.8.3 , and this
// specification ensures you’ll get the latest patch 
// release that will still compile with the code i

//_____________________________________________________
//_____________________________________________________

fn play_guess_game() {
    println!("Guess The Number!");

    let secret_number = rand::thread_rng().gen_range(1..=100);
    println!("Secret Number = {secret_number}.");    
    

// DESIGN PRINCIPLE
//      DESIGN TOWARDS IMMUTABILITY RATHER THAN MUTABILITY

// Type Idea
//      1. Type Inferrencing From R.H.S
//      2. Type Binding To LHS ( Inferred Type From RHS )
//      3. Type Inferrencing and Binding Happens At Compile Time

// The :: syntax in the ::new line indicates that new is an 
// associated function of the String type. An associated function 
// is a function that’s implemented on a type, in this case String .
// This new function creates a new, empty string. 

    // let mut guess = String::new();
    // io::stdin().read_line( &guess ).expect("Failed To Read Line");

// read_line puts whatever the user enters into the string 
// we pass to it, but it also returns a Result value. 
// Result is an enumeration, often called an enum, which is
// a type that can be in one of multiple possible states. 
// We call each possible state a variant.

// Result 's variants are Ok and Err . The Ok variant indicates 
// the operation was successful, and inside Ok is the 
// successfully generated value. 
// The Err variant means the operation failed, 
// and Err contains information about how or why the operation failed.

// Values of the Result type, like values of any type, 
// have methods defined on them. An instance of Result has an 
// expect method that you can call. If this instance of Result is an
// Err value, expect will cause the program to crash and display 
// the message that you passed as an argument to expect .

// If this instance of Result is an Ok value, expect will 
// take the return value that Ok is holding and return just
// that value to you so you can use it

    // let something = io::stdin().read_line( &mut guess );
     // ^^^^^^^^^ help: if this is intentional, prefix it with 
     //           an underscore: `_something`
    // let _something = io::stdin().read_line( &mut guess );
    // let _ = io::stdin().read_line( &mut guess );


    // let guess_again: u32 = guess.trim()
    //                         .parse()
    //                         .expect("Please Try A Number");
    
    loop {
        println!("Please input your guess.");

        let mut guess = String::new();

        io::stdin()
            // .read_line( &guess );
            // ---------  ^^^^^^ types differ in mutability
            .read_line( &mut guess ) // & Is Giving Reference/Address
            .expect("Failed To Read Line");

        // guess identifier Shadows Previous Definition
        // let guess: u32 = guess.trim()
        //                       .parse()
        //                       .expect("Please Try A Number");
        let guess: u32 = match guess.trim().parse() {
            Ok(number)  => number,
            Err(_)      => continue,
        };
  
        // match guess_again.cmp( &secret_number ) {
        match guess.cmp( &secret_number ) {
            Ordering::Less      => println!("Too Small!"),
            Ordering::Greater   => println!("Too Big!"),
            Ordering::Equal     => {
                println!("You Win!");
                break;
            }
        }

        println!("Your Guess: {guess}");
    }
}

//_____________________________________________________
//_____________________________________________________

fn play_mutability_immutability() {
    let apples = 55;
    // error[E0384]: cannot assign twice to immutable variable `apples`
    // apples = 555;
    println!("Apples: {apples}");

    let mut oranges = 100;
    println!("Oranges: {oranges}");
    oranges = 111;
    println!("Oranges: {oranges}");

    let x = 44;
    let y = 55;    

    println!("x = {} and y = {}", x, y );
    println!("x = {x} and y = {y}");

    let c = x + y;
    println!("c = {c}");

    const THREE_HOURS_IN_SECONDS: u32 = 3 * 60 * 60;
    println!("THREE_HOURS_IN_SECONDS : {THREE_HOURS_IN_SECONDS}");

    // Constants
    // Like immutable variables, constants are values 
    // that are bound to a name and are not allowed
    // to change, 

    //but there are a few differences between constants 
    // and variables.

    // First, you aren’t allowed to use mut with constants. 
    // Constants aren’t just immutable by default—
    // they’re always immutable. You declare constants 
    // using the const keyword instead of the let keyword, 
    // and the type of the value must be annotated

    // The last difference is that constants may be set only 
    // to a constant expression, not the result of a value 
    // that could only be computed at runtime.

    // const CONST_VALUE: u32 = c * 10 ;
    // -----------------        ^ non-constant value

    // Rust’s naming
    // convention for constants is to use all uppercase with 
    // underscores between words

    // const THREE_HOURS_IN_SECONDS: u32 = 3 * 60 * 60 * 100;

    // Constants are valid for the entire time a program runs, 
    // within the scope they were declared in
}

//_____________________________________________________

fn play_with_shadowing() {
    let x = 5;
    let x = x + 1; // Shadowing In Same Scope
    println!("The Value of x : {x}");

    { //Shadowing In Different Scope i.e. Local Scope 
        let x = x * 2;
        println!("The Value of x : {x}");
    } //Shadowing Will Go 

    println!("The Value of x : {x}");

// you can declare a new variable with the same name 
// as a previous variable. Rustaceans say that the first 
// variable is shadowed by the second, which means that 
// the second variable is what the compiler will see when 
// you use the name of the variable. In effect, the second 
// variable overshadows the first, taking any uses of the 
// variable name to itself until either it itself is shadowed 
// or the scope ends. We can shadow a variable by using the 
// same variable’s name and repeating the use of the let keyword

// Shadowing is different from marking a variable as mut , 
// because we’ll get a compile-time error if we accidentally 
// try to reassign to this variable without using the let 
// keyword. By using let , we can perform a few transformations 
// on a value but have the variable be immutable after those 
// transformations have been completed.

// The other difference between mut and shadowing is that 
// because we’re effectively creating a new variable when 
// we use the let keyword again, we can change the type of 
// the value but reuse the same name. 
    let spaces = "     ";
    println!("Spaces : {spaces}");

    let spaces = spaces.len();
    println!("Spaces : {spaces}");
}

//_____________________________________________________
//_____________________________________________________
//_____________________________________________________
//_____________________________________________________
//_____________________________________________________

fn main() {
    println!("\nFunction : play_guess_game");
    // play_guess_game();

    println!("\nFunction : play_mutability_immutability");
    play_mutability_immutability();

    println!("\nFunction : play_with_shadowing");
    play_with_shadowing();

    // println!("\nFunction : ");
    // println!("\nFunction : ");
    // println!("\nFunction : ");
    // println!("\nFunction : ");
    // println!("\nFunction : ");
}