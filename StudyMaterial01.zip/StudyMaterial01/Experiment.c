#include <stdio.h>

// Pre Processor Directives
#define PI 3.14

//____________________________________________

void doChange(int *demon) {
	*demon = 999;
}

void playWithConst() {
	int something = 10;

	printf("\n %d", something);
	something = 100;
	printf("\n %d", something);

	// Programmer Intention To Achieve Immutability
	const int somethingAgain = 9;
	printf("\n %d", somethingAgain);
	// somethingAgain = 99;

	int *demon = &somethingAgain;
	*demon = 99;
	printf("\n %d", somethingAgain);

	doChange( &somethingAgain );
	printf("\n %d", somethingAgain);
}

//____________________________________________

void playWithMacros() {
	float radius = 10.0;
	float area = PI * radius * radius;

	printf("\nArea : %f", area); 
}

//____________________________________________
//____________________________________________
//____________________________________________
//____________________________________________
//____________________________________________
//____________________________________________

void main() {
	printf("\n\nFunction : playWithConst");
	playWithConst();

	printf("\n\nFunction : playWithMacros");
	playWithMacros();

	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
}