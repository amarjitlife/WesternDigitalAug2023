//
// Enums and Pattern Matching
//
// Enumerations, also referred to as enums. 
// Enums allow you to define a type by enumerating its 
// possible variants. First, we’ll define and use an enum to
// show how an enum can encode meaning along with data.
//

// enums give you a way of saying a value is one of a 
//      possible set of values.

// class Messaage {
//     String textMessage;
//     String pictureMessage;
//     String linkMessage;

//     String joiningMessage;
//     String exitingMessage;
//     Time time;
//     User user;
// }

// Messaage joiningMessage  = Messaage( , , , , );

//_____________________________________________________

enum IpAddrKind {
    V4,
    V6,
}

fn route(ip_kind: IpAddrKind) {
    // Logic Goes Here...
}

fn play_with_ipaddress_enum () {
    let four = IpAddrKind::V4;
    let six = IpAddrKind::V6;

    route(IpAddrKind::V4);
    route(IpAddrKind::V6);
}

//_____________________________________________________

fn play_with_ipaddress_enum1() {
    enum IpAddrKind {
        V4,
        V6,
    }

    struct IpAddr {
        kind: IpAddrKind,
        address: String,
    }

    let home = IpAddr {
        kind: IpAddrKind::V4,
        address: String::from("127.0.0.1"),
    };

    let loopback = IpAddr {
        kind: IpAddrKind::V6,
        address: String::from("::1"),
    };
}


//_____________________________________________________

fn play_with_ipaddress_enum2() {

    enum IpAddr {
        V4(String),
        V6(String),
    }

    let home = IpAddr::V4(String::from("127.0.0.1"));
    let loopback = IpAddr::V6(String::from("::1"));
}

fn play_with_ipaddress_enum3() {
    
    enum IpAddr {
        V4(u8, u8, u8, u8),
        V6(String),
    }

    let home = IpAddr::V4(127, 0, 0, 1);
    let loopback = IpAddr::V6(String::from("::1"));
}

fn play_with_ipaddress_enum4() {
    struct Ipv4Addr {
        u8 part1,
        u8 part2,
        u8 part3,
        u8 part4,
    }

    struct Ipv6Addr {
        // --snip--
    }

    enum IpAddr {
        V4(Ipv4Addr),
        V6(Ipv6Addr),
    }
}

//_____________________________________________________

struct QuitMessage; // unit struct
struct MoveMessage {
    x: i32,
    y: i32,
}

struct WriteMessage(String); // tuple struct
struct ChangeColorMessage(i32, i32, i32); // tuple struct

// There is one more similarity between enums and structs: just as we’re able to define
// methods on structs using impl , we’re also able to define methods on enums.

fn play_with_message_enum() {
    enum Message {
        Quit,
        Move { x: i32, y: i32 },
        Write(String),
        ChangeColor(i32, i32, i32),
    }

    impl Message {

        fn call(&self) {
            // method body would be defined here
        }
    }

    let m = Message::Write(String::from("hello"));
    m.call();
}

//_____________________________________________________
// COMPILATION ERROR

//_____________________________________________________
//_____________________________________________________
//_____________________________________________________
//_____________________________________________________
//_____________________________________________________
//_____________________________________________________

fn main() {
    println!("\nFunction : play_with_ipaddress_enum");
    play_with_ipaddress_enum();

    // println!("\nFunction : ");
    // println!("\nFunction : ");
    // println!("\nFunction : ");
    // println!("\nFunction : ");
    // println!("\nFunction : ");
    // println!("\nFunction : ");
    // println!("\nFunction : ");
    // println!("\nFunction : ");
    // println!("\nFunction : ");
}
