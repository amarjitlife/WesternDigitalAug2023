______________________________________________________

DAY 01
______________________________________________________
	
	The C Programming Language, 2nd Edition
		By Kernigham and Denish Ritchie

		Chapter 01 : Types, Operators and Expressions
		Chapter 02 : Control Structures

______________________________________________________

DAY 02
______________________________________________________
	
	The C Programming Language, 2nd Edition
		By Kernigham and Denish Ritchie

		Read Arrays and Pointers Chapter

______________________________________________________

DAY 03/04
______________________________________________________
	
	The C Programming Language, 2nd Edition
		By Kernigham and Denish Ritchie

		Read Arrays and Pointers Chapter

______________________________________________________

DAY 05
______________________________________________________
	
	Rust Programming Book : Rust Official Guide
		Structures 					Reading and Hands On
		Enums and Pattern Mathching Reading and Hands On

______________________________________________________
______________________________________________________
______________________________________________________
______________________________________________________
______________________________________________________
______________________________________________________
______________________________________________________

