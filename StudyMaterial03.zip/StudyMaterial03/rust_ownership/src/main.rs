// Create New Project
// cargo new rust_ownership

// Rust Ownership
// Ownership is Rust’s most unique feature and has deep 
// implications for the rest of the language (system). 
// It enables Rust to make memory safety guarantees 
// without needing a garbage collector

// Ownership is a set of rules that governs 
// how a Rust program manages memory.

// main purpose of ownership is to manage heap data

// In Java/Python
// Some languages have garbage collection that regularly 
// looks for no-longer used memory as the program
// runs; in other languages, 

// In C/C++
// The programmer must explicitly allocate and free the memory. 

// Rust uses a third approach: memory is managed through 
// a system of ownership with a set of rules that the 
// compiler checks. If any of the rules are violated, 
// the program won’t compile.

// None of the features of ownership will slow down your program 
// while it’s running.

// The Stack and the Heap
// Many programming languages don’t require you to think about the stack and the heap
// very often. But in a systems programming language like Rust, whether a value is on the
// stack or the heap affects how the language behaves and why you have to make certain
// decisions. Parts of ownership will be described in relation to the stack and the heap

// popping off the stack. All data stored on the
// stack must have a known, fixed size. Data with an unknown size at compile time or a
// size that might change must be stored on the heap instead.

// The heap is less organized: when you put data on the heap, you request a certain
// amount of space. The memory allocator finds an empty spot in the heap that is big
// enough, marks it as being in use, and returns a pointer, which is the address of that
// location. This process is called allocating on the heap and is sometimes abbreviated asjust allocating (pushing values onto the stack is not considered allocating). Because the
// pointer to the heap is a known, fixed size, you can store the pointer on the stack, but
// when you want the actual data, you must follow the pointer.


// OWNERSHIP RULES IN RUST
// 1. Each value in Rust has an owner.
// 2. There can only be one owner at a time.
// 3. When the owner goes out of scope, the value will be dropped.

//_____________________________________________________

fn play_with_scope() {
    // s Is Not Valid Here...

    let s = "Hello World"; // s Is Valid From This Point Onwards

    // Do Stuff With s
    println!("Value : {s}");
} // This Scope Is Now Over, Hence s Is No Longer Valid

// Two important points in time here:
//     When s comes into scope, it is valid.
//     It remains valid until it goes out of scope.


// In Java
    // String Kerning : Compiler Optimation Technique
    // String something        = "Good Morning!";
    // String somethingAgain   = "Good Morning!";

    // System.out.println( something == somethingAgain );

    // String something1       = new String("Good Morning!");
    // String somethingAgain1  = new String("Good Morning!");
    // System.out.println( something1 == somethingAgain1 );

//_____________________________________________________

fn play_with_string() {
    // s1 Is Not Valid Here...

    // String::from Allocates Memory At Heap i.e. Calling malloc
    let mut s1 = String::from("Hello"); // s1 Is Valid From This Point Onwards

    // Do Stuff With s1
    s1.push_str(" World!"); // Mutating String!
    println!("Value : {s1}");

    let s2 = s1;            // Move Semantics
    println!("Value : {s2}");    
    // println!("Value : {s1}");

    // Creating Exact Replica/Clone With It's Own Heap Memory
    let mut s3 = s2.clone(); 
    s3.push_str("#####");  // Mutating String!
    println!("Value : {s3}");
    println!("Value : {s2}");    

    let x = 5;              // Copy Semantics
    let y = x;
    println!("Value : {x}");    
    println!("Value : {y}");
} // This Scope Is Now Over, Hence s Is No Longer Valid

// RUST COPY SEMANTICS RULES
// As a general rule, any group of simple scalar values can implement
//     Copy , and nothing that requires allocation or is some form of resource can implement
//     Copy . Here are some of the types that implement Copy :
//     All the integer types, such as u32 .
//     The Boolean type, bool , with values true and false .
//     All the floating point types, such as f64 .
//     The character type, char .
//     Tuples, if they only contain types that also implement Copy . For example, (i32, i32)
//     implements Copy , but (i32, String) does not.

// Rust has a special annotation called the Copy trait that 
// we can place on types that are stored on the stack, as 
// integers are. If a type implements the Copy trait, variables 
// that use it do not move, but rather are trivially copied,
// making them still valid after assignment to another variable.

// Rust won’t let us annotate a type with Copy if the type, or 
// any of its parts, has implemented the Drop trait. If the type 
// needs something special to happen when the value goes out of
// scope and we add the Copy annotation to that type, we’ll get 
// a compile-time error

//_____________________________________________________

fn takes_ownership( some_string: String ) {
    println!("String Inside takes_ownership : {}", some_string);
}

fn makes_copy( some_integer: i32 ) {
    println!("Integer Inside makes_copy: {}", some_integer);
}

fn gives_ownership() -> String {
    let give_something = String::from("Give Give Give!!!");

    println!("String Inside gives_ownership: {}", give_something);
    
    //  An Expression Having Return Value
    //  It Will Become Return Value Of Block { }
    give_something 
}

fn takes_and_gives_ownership( some_string : String ) -> String {
    println!("String Inside takes_and_gives_ownership: {}", some_string );

    //  An Expression Having Return Value
    //  It Will Become Return Value Of Block { }
    some_string 
}

fn play_with_function_ownership() {
    // Creating String Object In Heap
    let some = String::from("Hello");   // move occurs because `some` has type `String`, 
                                        //  which does not implement the `Copy` 
    
    println!("String Before takes_ownership : {}", some); // ---- value moved here
    takes_ownership( some ); // Move Semantics
    
    // Compilation Error: ^^^^ value borrowed here after move
    // println!("String After takes_ownership : {}", some); 

    let some_again = 111;

    println!("Integer Before makes_copy: {}", some_again);
    makes_copy( some_again );
    println!("Integer After makes_copy: {}", some_again);

    let got_something = gives_ownership();
    println!("String Outside gives_ownership: {}", got_something);

    let take_and_give = String::from("Give Take Give Take!!!");
    // let got_something_again = takes_and_gives_ownership( take_and_give )
    // println!("String Inside takes_and_gives_ownership: {}", got_something_again );
    let take_and_give = takes_and_gives_ownership( take_and_give );
    println!("String Inside takes_and_gives_ownership: {}", take_and_give );
}

// OWNERSHIP IMPORTANT POINT
// The ownership of a variable follows the same pattern every time: 
// assigning a value to another variable MOVES IT. 
// When a variable that includes data on the heap goes out of 
// scope, the value will be cleaned up by drop unless ownership of 
// the data has been moved to another variable.

//_______________________________________________________________

fn calculate_length_with_ownership( some_string: String ) -> (String, usize) {
    let length = some_string.len();

    // Suppose You Want To Return Calculated Result Also!
    // Return Tuple Of Values!!!
    (some_string, length)
}

fn play_with_calcualte() {
    let some = String::from("Hello World!");

    println!("String Before calculate_length: {}", some);
    let (some, length) = calculate_length_with_ownership( some );
    println!("String After calculate_length: {}", some);
    println!("String Length After calculate_length: {}", length);
}

// Function : play_with_ownership_result_pattern
// String Before calculate_length: Hello World!
// String After calculate_length: Hello World!
// String Length After calculate_length: 12

//_______________________________________________________________
//                      NOTE NOTE NOTE NOTE
//_______________________________________________________________
// IN RUST

// What if we want to let a function use a value but not take ownership?
// Rust has a feature for using a value without 
//      transferring ownership, called references.

// Instead, we can provide a reference to the String value. 

// A reference is like a pointer in that it’s an address we can 
// follow to access the data stored at that address; 
// that data is owned by some other variable. 
// _____________________________________________
//              VERY IMPORTANT POINT
// _____________________________________________
// Unlike a pointer, a reference is guaranteed to point to 
// a valid value of a particular type for the 
// life of that reference.


//  HENCE REFFRENCE NATURE IN LANGUAGES
//_______________________________________________________________
//  LANGUAGE        REFERNCE NATURE     DESCRIPTION
//_______________________________________________________________
//  In C            RAW POINTER         Reference Pointing To Any Location
//                                      Will Not Be Set To NULL By Default
//
//  In JAVA         SAFE POINTER        Reference Pointing To Location In Heap
//                                      Will Be Set To NULL By Default After Scope Ends

//  In RUST         VALID POINTER       Reference Pointing To Valid Location
//                                      Valid Reference Points To Valid Object/Value 
//                                      Valid Object/Value i.e. Having Owner

//_______________________________________________________________

fn calculate_length_without_ownership( some_string: &String ) -> usize {
    let length = some_string.len();

    length
}

// fn takes_ownership_and_destroy( some_string: String ) {
//     println!("Took Ownership and Destoryed: {}", some_string);
// }

fn play_with_calcualte_again() {
    let some = String::from("Hello World!");

    println!("String Before calculate_length: {}", some);

    // Moving Ownership and Making some Invalid
    // let take_some_ownership = some;   
    // takes_ownership_and_destroy( some );

    let length = calculate_length_without_ownership( &some );
    println!("String After calculate_length: {}", some);
    println!("String Length After calculate_length: {}", length);
}

// Function : play_with_calcualte_again
// String Before calculate_length: Hello World!
// String After calculate_length: Hello World!
// String Length After calculate_length: 12

//_______________________________________________________________

fn makes_ten_times( some_integer: &i32 ) -> i32 {
    // Rust Compiler Will Generate Code >> let result = (*some_integer) * 10;
    //      For Following Line
    let result1 = some_integer * 10; 
    println!("Inside makes_ten_times: {}", result1);

    let result2 = ( *some_integer ) * 10; 
    println!("Inside makes_ten_times: {}", result2);

    result1
}

fn play_with_primitive_references() {
    let some = 11;

    println!("Before makes_ten_times: {}", some);
    let some = makes_ten_times( &some );
    println!("After makes_ten_times: {}", some);
}

// RUST COMMENTORY
// When functions have references as parameters 
// instead of the actual values, we won’t need to 
// return the values in order to give back ownership, 
// because we never had ownership.

// RUST BORROWING
// We call the action of creating a reference borrowing. 

// As in real life, if a person owns something, you can borrow 
// it from them. When you’re done, you have to give it back.

//_______________________________________________________________

// IN RUST
//      Just as variables are immutable by default, so are references. 
//      We’re not allowed to modify something we have a reference to.

//      To allow us to modify a borrowed value with just a few
//      small tweaks that use, instead, a mutable reference:

// fn change_string( some_string: &String ) {
fn change_string( some_string: &mut String ) {
    some_string.push_str(" World!");
}

fn play_with_modifying_borrow() {
    // let some = String::from("Hello");

    let mut some = String::from("Hello");

    println!("Before changeString: {}", some);
    // change_string( &some );    // ------------  ^^^^^ types differ in mutability
    
    change_string( &mut some ); 
    println!("After changeString: {}", some);
}

// Function : play_with_modifying_borrow
// Before changeString: Hello
// After changeString: Hello World!

//_______________________________________________________________


fn play_with_mutable_references() {
    // let mut some = String::from("Hello");
    // let mut some: &mut String = String::from("Hello"); // ^^^^^^expected `&mut String`, found `String`
    let mut some: String = String::from("Hello"); // some Is Reference To String Object

    let reference1: &mut String = &mut some; // reference1 Is Mutable Reference To String
    // let _reference11: &String = &some;        // reference11 Is Reference To String
                                // ^^^^^ immutable borrow occurs here

    // let reference2 = &mut some;

    println!("Values : {}", reference1);
    // println!("Values : {} {}", reference1, reference2);
}

// RUST MUTABILITY RESTRICTIONS

// The restriction preventing multiple mutable references to 
// the same data at the same time allows for mutation but in 
// a very controlled fashion. It’s something that new Rustaceans
// struggle with, because most languages let you mutate whenever
// you’d like. The benefit of having this restriction is that 
// Rust can prevent data races at compile time. 

// A data race is similar to a race condition and happens when 
// these three behaviors occur:

    // 1. Two or more pointers access the same data at the same time.
    // 2. At least one of the pointers is being used to write to the data.
    // 3. There’s no mechanism being used to synchronize access to the data.

// Data races cause undefined behavior and can be difficult to 
// diagnose and fix when you’re trying to track them down at 
// runtime; Rust prevents this problem by refusing to compile
// code with data races!


//_______________________________________________________________

// SCOPE AND REFERENCES

// As always, we can use curly brackets to create a 
// new scope, allowing for multiple mutable references, 
// just not simultaneous ones:

// The ability of the compiler to tell that a reference is 
// no longer being used at a point before the end of the 
// scope is called Non-Lexical Lifetimes (NLL for short),

// Note that a reference’s scope starts from where it is 
// introduced and continues through the last time that 
// reference is used.

// Rust enforces a similar rule for combining mutable and 
// immutable references.

// In Rust, by contrast, the compiler guarantees that 
// references will never be dangling references: if you have 
// a reference to some data, the compiler will ensure that 
// the data will not go out of scope before the
// reference to the data does

// RUST MUTABILITY RESTRICTIONS

// We also cannot have a mutable reference while we have 
// an immutable one to the same value

// Users of an immutable reference don’t expect the value to 
// suddenly change out from under them! However, multiple 
// immutable references are allowed because no one who is 
// just reading the data has the ability to affect anyone 
// else’s reading of the data.

// Users of an immutable reference don’t expect the value to 
// suddenly change out from under them! However, multiple immutable 
// references are allowed because no one who is just reading 
// the data has the ability to affect anyone else’s reading of the data.

fn play_with_mutable_references_again() {
    let mut s = String::from("Some String");
    
    { // New Scope
        let _r1 = &mut s;
    } // r1 goes out of scope here, so we can make a new 
     // reference with no problems.
    
    let _r2 = &mut s;


    let mut ss = String::from("Some String Again");
    let r11 = &ss;
    let r12 = &ss;

    // let r13 = &mut ss; 
    // |               ^^^^^^^ mutable borrow occurs here

    println!("{} {}", r11, r12);
    // println!("{} {} {}", r11, r12, r13);
}

//_______________________________________________________________

// In Rust, by contrast, the compiler guarantees that references 
// will never be dangling references: if you have a reference to
// some data, the compiler will ensure that the data will not 
// go out of scope before the reference to the data does.

// fn get_dangling() -> &String {
//     let some = String::from("Hello");

//     &some
// }

fn better_solution() -> String {
    let some = String::from("Hello");

    some
}

fn play_with_dangling_reference() {
    // let something = get_dangling();

    let something = better_solution();
    println!("Value: {}", something);
}

// IN RUST ::: The Rules of References
// Let’s recap what we’ve discussed about references:
//     At any given time, you can have either one mutable reference 
//         or any number of immutable references.
//     References must always be valid.

//_______________________________________________________________

fn first_word(s: &String) -> usize {
    let bytes = s.as_bytes();

    // Sequences of Tuples : (index, value)
    for (i, &item) in bytes.iter().enumerate() {
        if item == b' ' {
            return i;
        }
    }
    s.len()
}

fn play_with_first_word() {
    let mut sentence = String::from("How are you doing?");

    println!("Sentence : {sentence}");

    let word = first_word( &sentence );
    println!("\nResult : {word}");

    sentence.clear();
    println!("Sentence : {sentence}");
}

//_______________________________________________________________

fn first_word_better(s: &String) -> &str { //String {
    let bytes = s.as_bytes();

    for (i, &item) in bytes.iter().enumerate() {
        if item == b' ' {
            return &s[0..i];
        }
    }
    // s.len()
    &s[..]
}

fn play_with_first_word_better() {
    let mut sentence = String::from("How are you doing?");

    println!("Sentence : {sentence}");

    let word = first_word_better( &sentence );
    println!("\nWord : {word}");

    sentence.clear();
    println!("Sentence : {sentence}");
}

//_______________________________________________________________

fn first_word_best(s: &str) -> &str { //String {
    let bytes = s.as_bytes();

    for (i, &item) in bytes.iter().enumerate() {
        if item == b' ' {
            return &s[0..i];
        }
    }
    // s.len()
    &s[..]
}

fn play_with_first_word_best() {
    let my_string = String::from("hello world");

    // `first_word` works on slices of `String`s, whether partial or whole
    let word = first_word_best(&my_string[0..6]);
    let word = first_word_best(&my_string[..]);
    // `first_word` also works on references to `String`s, which are equivalent
    // to whole slices of `String`s
    let word = first_word_best(&my_string);

    let my_string_literal = "hello world";

    // `first_word` works on slices of string literals, whether partial or whole
    let word = first_word_best(&my_string_literal[0..6]);
    let word = first_word_best(&my_string_literal[..]);

    // Because string literals *are* string slices already,
    // this works too, without the slice syntax!
    let word = first_word_best(my_string_literal);
}

// IMPORTANT POINT
// Note: String slice range indices must occur at valid UTF-8 character boundaries. 
// If you attempt to create a string slice in the middle of a multibyte character, 
// your program will exit with an error. For the purposes of introducing string 
// slices, we are assuming ASCII only in this section; a more thorough discussion
// of UTF-8 handling is in the “Storing UTF-8 Encoded Text with Strings” section


// BEST PRACTICES RUST API DESIGN
// If we have a string slice, we can pass that directly. 
// If we have a String , we can pass a slice of the String 
// or a reference to the String . 
// This flexibility takes advantage of deref coercions,

// Defining a function to take a string slice instead of a 
// reference to a String makes our API more general and 
// useful without losing any functionality:

//_______________________________________________________________

fn play_with_array_slice() {
    let a = [1, 2, 3, 4, 5];
    let slice = &a[1..3];

    let _slice1: &[i32] = &a[1..3];

    assert_eq!(slice, &[2, 3]);
}

//_______________________________________________________________
// COMPILATION ERROR

//_______________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAGS|HANDS!

// https://codebunk.com/b/2381100613831/
// https://codebunk.com/b/2381100613831/
// https://codebunk.com/b/2381100613831/
// https://codebunk.com/b/2381100613831/


//_____________________________________________________
//_____________________________________________________
//_____________________________________________________
//_____________________________________________________
//_____________________________________________________
//_____________________________________________________
//_____________________________________________________

fn main() {
    println!("\nFunction : play_with_scope");
    play_with_scope();

    println!("\nFunction : play_with_string");
    play_with_string();

    println!("\nFunction : play_with_function_ownership");
    play_with_function_ownership();

    println!("\nFunction : play_with_calcualte");
    play_with_calcualte();

    println!("\nFunction : play_with_calcualte_again");
    play_with_calcualte_again();

    println!("\nFunction : play_with_primitive_references");
    play_with_primitive_references();

    println!("\nFunction : play_with_modifying_borrow");
    play_with_modifying_borrow();

    println!("\nFunction : play_with_mutable_references");
    play_with_mutable_references();

    println!("\nFunction : play_with_mutable_references_again");
    play_with_mutable_references_again();

    println!("\nFunction : play_with_dangling_reference");
    play_with_dangling_reference();

    println!("\nFunction : play_with_array_slice");
    play_with_array_slice();

    // println!("\nFunction : ");
    // println!("\nFunction : ");
    // println!("\nFunction : ");
    // println!("\nFunction : ");
    // println!("\nFunction : ");
    // println!("\nFunction : ");
    // println!("\nFunction : ");
}
