
import string
import sys

fileNames = sys.args[ 1 : ]

def betterCountWords():
	wordsCount = {}

	for fileName in fileNames:
		for line in open( fileName ):
			for word in line.split():
				word = word.strip()
				if len( word ) >= 2:
					wordsCount[word] = wordsCount.get(word, 0) + 1

	print( wordsCount )

#__________________________________________________

def countWords(filenames):
	wordsCount = {}

	for filename in filenames:
	 	openedFile = open(filename)

	 	lines = openedFile.readlines()
	 	
	 	for line in lines:
	 		words = line.split()
	 	
	 		for word in words:
	 			word = word.strip()
	 			if len(word) >= 2:
	 				wordsCount[word] = wordsCount.get(word, 0) + 1

	 	openedFile.close()
	return wordsCount

#__________________________________________________

