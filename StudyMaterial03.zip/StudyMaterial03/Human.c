#include <stdio.h>

typedef struct human_type {
	int id;
	char name[100];
	void (*dance)();

	// void (*singing)();
	// void ** VPTR; 
} Human;

// In Mathematics
//		Variable Definition = { states }
//		Object 	 Definition = { states, Metastate }
//			Object Have Capability To Send/Receive Messages

// C++
// class Human {
							// Data/State
// 		int id;
// 		char name[100];

// 		void **VPTR; // Meta Data 
// }

// // Name Mangling
// void Human_doDance_i(int something) {

// }

// void Human_doDance_ii(int something, int something) {

// }

// void Human_doDance() {

// }		

// In Java/C++/C#
// class Human {
// 		int id;
// 		char name[100];
// 		void (*dance)();

// 		void doHipHopDance() {
// 			printf("\nDoing Hip Hop Dance...");
// 		}

// 		void doDance(int something) {

// 		}

// 		void doDance(int something, int something) {

// 		}

// 		void doDance() {

// 		}		
// }

void doHipHopDance() {
	printf("\nDoing Hip Hop Dance...");
}

void doFreeStyleDance() {
	printf("\nDoing Free Style Dance...");
}

void doBalletSinging() {
	printf("\nDoing Ballet Singing...");
}

void doMetallicaSinging() {
	printf("\nDoing Metallica Singing...");
}

void playWithHuman() {
					  // Constructor 			// Message To Method Table
	Human tom 		= { 420, "Tom Cruise"	, 	doHipHopDance, doMetallicaSinging };
	Human angelina 	= { 100, "Angelina Joli", 	doFreeStyleDance, doBalletSinging };

	printf("\nHuman ID 		: %d", tom.id );
	printf("\nHuman Name	: %s", tom.name );

	// tom Is An Object
	//		Capability To Receive Message
	tom.dance();
	tom.singing();

	printf("\nHuman ID 		: %d", angelina.id );
	printf("\nHuman Name	: %s", angelina.name );
	angelina.dance();
	angelina.singing();
}

int main() {
	playWithHuman();

}

// $ ./human 

// Human ID 		: 420
// Human Name	: Tom Cruise
// Doing Hip Hop Dance...
// Human ID 		: 100
// Human Name	: Angelina Joli
// Doing Free Style Dance...(base)
