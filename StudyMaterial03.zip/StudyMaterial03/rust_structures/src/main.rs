
// A struct, or structure, is a custom data type that 
// lets you package together and name multiple related 
// values that make up a meaningful group.

#[derive(Debug)]
struct User  {
    // mut active: bool,
    active : bool,
    username: String,
    email: String,
    sign_in_count: u64,
}

// DESIGN PRINCIPLE
//      DESIGN TOWARDS IMMUTABIILITY RAHTER THAN MUTABILIITY

// Note that the entire instance must be mutable; 
// Rust doesn’t allow us to mark only certain fields as mutable. 
// As with any expression, we can construct a new instance of 
// the struct as the last expression in the function body to 
// implicitly return that new instance.

fn play_with_user(){

    let user1 = User {
        email: String::from("someone@example.com"),
        username: String::from("someusername123"),
        active: true,
        sign_in_count: 1,
    };

    // Compiler Error: ^^^^^^^^^^^ cannot assign
    // user1.email = String::from("changed@email.com");

    println!("User 1: {:?}", user1);
    println!("User 1: {:#?}", user1);

    let mut user2 = User {
        email: String::from("someone@example.com"),
        username: String::from("someusername123"),
        active: true,
        sign_in_count: 1,
    };

    user2.email = String::from("changed@email.com");
    user2.active = false;

    println!("User 2: {:?}", user2);
    println!("User 2: {:#?}", user2);

    // let user3 = User {
    //     mut active: true,
    //     username: String::from("Mansa"),
    //     email:String::from("Dell"),
    //     sign_in_count: 1,
    // };

    let user4 = User {
        active: true,
        username: user1.username,
        email: user1.email,
        sign_in_count: user1.sign_in_count,
    };

    let user5 = User {
        active: true,
        username: String::from("Mansa"),
        email:String::from("Dell"),
        sign_in_count: 1,
    };

    // Folloiwng Is Shortcut Syntax For Above
    let user6 = User {
        active: false,
        ..user5  // Rest Of Fields Intiialsed From user5
    };
}

//_____________________________________________________

fn build_user( email : String, username: String) -> User {
    User {
        active: true,
        username: username,
        email: email,
        sign_in_count: 1,
    }
}

fn build_user_better( email : String, username: String) -> User {
    User {
        active: true,
        username,
        email,
        sign_in_count: 1,
    }
}

fn play_with_build_user() {
    let mansa = build_user( String::from("mansa@dell.com"),
                            String::from("mansa"));

    let mansa1 = build_user_better( String::from("mansa@dell.com"),
                            String::from("mansa"));

}

//_____________________________________________________

struct Color(i32, i32, i32);
struct Point(i32, i32, i32);

// Unit Like Structure
struct AlwaysEqual;

fn play_with_tuple_struct() {
    let _black = Color(0, 0, 0);
    let _origin = Point(0, 0, 0);

    let _subject = AlwaysEqual;
}

//_____________________________________________________

fn area(width: u32, height: u32) -> u32 {
    width * height
}

fn area_better(dimensions: (u32, u32)) -> u32 {
   dimensions.0 * dimensions.1
}

#[derive(Debug)]
struct Rectangle {
    width: u32,
    height: u32,
}

fn area_best( rectangle : Rectangle )  -> u32 {
   rectangle.width * rectangle.height
}

fn play_with_area() {
    let width1 = 30;
    let height1 = 50;

    let result = area(width1, height1);
    println!("Rectangle Area: {}", result);

    let result = area_better( (width1, height1) );
    println!("Rectangle Area: {}", result);

    let rectangle = Rectangle {
        width: 30,
        height: 50,
    };

    println!("Rectangle : {:?} ", rectangle );
    let result = area_best( rectangle );
    println!("Rectangle Area: {}", result);
}

//_____________________________________________________

#[derive(Debug)]
struct Rectangle1 {
    width: u32,
    height: u32,
}

// Implementation Block
//      Contains Methods Implementation
impl Rectangle1 {

    fn area( &self ) -> u32 {
        self.width * self.height
    }

    fn width(&self) -> bool {
        self.width > 0
    }

    fn can_hold(&self, other: &Rectangle1) -> bool {
        self.width > other.width && self.height > other.height
    }

    // Type Member Function :: Associated Function
    //      Function Associated With struct Context
    fn square(size: u32) -> Self {
        Self {
            width: size,
            height: size,
        }
    }
}

// impl Rectangle1 {

// }

fn play_with_rectangle_area() {
    let rect1 = Rectangle1 {
        width: 30,
        height: 50,
    };

    println!("Rectangle Area: {}", rect1.area() );
    println!("Rectangle Width: {}", rect1.width() );

    let _= Rectangle1::square(10);
}

// The method syntax goes after an instance: we add a dot followed by
// the method name, parentheses, and any arguments.

// In the signature for area , we use &self instead of rectangle: &Rectangle . The &self is
// actually short for self: &Self . Within an impl block, the type Self is an alias for the type
// that the impl block is for. Methods must have a parameter named self of type Self for
// their first parameter, so Rust lets you abbreviate this with only the name self in the first
// parameter spot. 

// Note that we still need to use the & in front of the self shorthand to
// indicate this method borrows the Self instance, just as we did in rectangle: &Rectangle .
// Methods can take ownership of self , borrow self immutably as we’ve done here, or
// borrow self mutably, just as they can any other parameter.

// We’ve chosen &self here for the same reason we used &Rectangle in the function version:
// we don’t want to take ownership, and we just want to read the data in the struct, not write to
// it. If we wanted to change the instance that we’ve called the method on as part of what the
// method does, we’d use &mut self as the first parameter

// VERY VERY IMPORTANT POINT
// Having a method that takes
// ownership of the instance by using just self as the first parameter is rare; this technique is
// usually used when the method transforms self into something else and you want to
// prevent the caller from using the original instance after the transformation.

// Note that we can choose to give a method the same name as one of the struct’s fields.
// Often, but not always, when we give methods with the same name as a field we want it to
// only return the value in the field and do nothing else. Methods like this are called getters,
// and Rust does not implement them automatically for struct fields as some other languages
// do. Getters are useful because you can make the field private but the method public and
// thus enable read-only access to that field as part of the type’s public API.


//_____________________________________________________

// Where’s the -> Operator?

// In C and C++, two different operators are used for calling methods: you use . if you’re
// calling a method on the object directly and -> if you’re calling the method on a pointer
// to the object and need to dereference the pointer first. In other words, if object is a
// pointer, 

// object->something() is similar to (*object).something()
 .
// Rust doesn’t have an equivalent to the -> operator; instead, Rust has a feature called
// automatic referencing and dereferencing. Calling methods is one of the few places in Rust
// that has this behavior.
// Here’s how it works: when you call a method with object.something() , Rust
// automatically adds in & , &mut , or * so object matches the signature of the method.
// In other words, the following are the same:

// p1.distance(&p2);
// (&p1).distance(&p2);

// The first one looks much cleaner. This automatic referencing behavior works because
// methods have a clear receiver—the type of self . Given the receiver and name of a
// method, Rust can figure out definitively whether the method is reading ( &self ),
// mutating ( &mut self ), or consuming ( self ). The fact that Rust makes borrowing
// implicit for method receivers is a big part of making ownership ergonomic in practice.


//_____________________________________________________

// Associated Functions

// All functions defined within an impl block are called associated functions because they’re
// associated with the type named after the impl . We can define associated functions that
// don’t have self as their first parameter (and thus are not methods) because they don’t
// need an instance of the type to work with. We’ve already used one function like this: the
// String::from function that’s defined on the String type.
// Associated functions that aren’t methods are often used for constructors that will return a
// new instance of the struct. These are often called new , but new isn’t a special name and isn’t
// built into the language.


//_____________________________________________________
//_____________________________________________________
//_____________________________________________________
// COMPILATION ERROR

//_____________________________________________________
//_____________________________________________________
//_____________________________________________________
//_____________________________________________________
//_____________________________________________________
//_____________________________________________________

fn main() {
    println!("\nFunction : play_with_user");
    play_with_user();

    println!("\nFunction : play_with_build_user");
    play_with_build_user();

    println!("\nFunction : play_with_tuple_struct");
    play_with_tuple_struct();

    println!("\nFunction : play_with_area");
    play_with_area();

    // println!("\nFunction : ");
    // println!("\nFunction : ");
    // println!("\nFunction : ");
    // println!("\nFunction : ");
    // println!("\nFunction : ");
    // println!("\nFunction : ");
    // println!("\nFunction : ");
    // println!("\nFunction : ");
    // println!("\nFunction : ");
    // println!("\nFunction : ");
}

