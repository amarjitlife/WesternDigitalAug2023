// By default, Rust has a set of items defined in the 
// standard library that it brings into the
// scope of every program. This set is called the prelude

use std::io;
use std::cmp::Ordering;
use rand::Rng;

//_____________________________________________________

// Cargo understands Semantic
// Versioning (sometimes called SemVer), which is a 
// standard for writing version numbers. The
// number 0.8.3 is actually shorthand for ^0.8.3 , 
// which means any version that is at least
// 0.8.3 but below 0.9.0 .

// Cargo considers these versions to have public APIs 
// compatible with version 0.8.3 , and this
// specification ensures you’ll get the latest patch 
// release that will still compile with the code i

//_____________________________________________________
//_____________________________________________________

#[allow(dead_code)]
fn play_guess_game() {
    println!("Guess The Number!");

    let secret_number = rand::thread_rng().gen_range(1..=100);
    println!("Secret Number = {secret_number}.");    
    

// DESIGN PRINCIPLE
//      DESIGN TOWARDS IMMUTABILITY RATHER THAN MUTABILITY

// Type Idea
//      1. Type Inferrencing From R.H.S
//      2. Type Binding To LHS ( Inferred Type From RHS )
//      3. Type Inferrencing and Binding Happens At Compile Time

// The :: syntax in the ::new line indicates that new is an 
// associated function of the String type. An associated function 
// is a function that’s implemented on a type, in this case String .
// This new function creates a new, empty string. 

    // let mut guess = String::new();
    // io::stdin().read_line( &guess ).expect("Failed To Read Line");

// read_line puts whatever the user enters into the string 
// we pass to it, but it also returns a Result value. 
// Result is an enumeration, often called an enum, which is
// a type that can be in one of multiple possible states. 
// We call each possible state a variant.

// Result 's variants are Ok and Err . The Ok variant indicates 
// the operation was successful, and inside Ok is the 
// successfully generated value. 
// The Err variant means the operation failed, 
// and Err contains information about how or why the operation failed.

// Values of the Result type, like values of any type, 
// have methods defined on them. An instance of Result has an 
// expect method that you can call. If this instance of Result is an
// Err value, expect will cause the program to crash and display 
// the message that you passed as an argument to expect .

// If this instance of Result is an Ok value, expect will 
// take the return value that Ok is holding and return just
// that value to you so you can use it

    // let something = io::stdin().read_line( &mut guess );
     // ^^^^^^^^^ help: if this is intentional, prefix it with 
     //           an underscore: `_something`
    // let _something = io::stdin().read_line( &mut guess );
    // let _ = io::stdin().read_line( &mut guess );


    // let guess_again: u32 = guess.trim()
    //                         .parse()
    //                         .expect("Please Try A Number");
    
    loop {
        println!("Please input your guess.");

        let mut guess = String::new();

        io::stdin()
            // .read_line( &guess );
            // ---------  ^^^^^^ types differ in mutability
            .read_line( &mut guess ) // & Is Giving Reference/Address
            .expect("Failed To Read Line");

        // guess identifier Shadows Previous Definition
        // let guess: u32 = guess.trim()
        //                       .parse()
        //                       .expect("Please Try A Number");
        let guess: u32 = match guess.trim().parse() {
            Ok(number)  => number,
            Err(_)      => continue,
        };
  
        // match guess_again.cmp( &secret_number ) {
        match guess.cmp( &secret_number ) {
            Ordering::Less      => println!("Too Small!"),
            Ordering::Greater   => println!("Too Big!"),
            Ordering::Equal     => {
                println!("You Win!");
                break;
            }
        }

        println!("Your Guess: {guess}");
    }
}

//_____________________________________________________
//_____________________________________________________

fn play_mutability_immutability() {
    let apples = 55;
    // error[E0384]: cannot assign twice to immutable variable `apples`
    // apples = 555;
    println!("Apples: {apples}");

    let mut oranges = 100;
    println!("Oranges: {oranges}");
    oranges = 111;
    println!("Oranges: {oranges}");

    let x = 44;
    let y = 55;    

    println!("x = {} and y = {}", x, y );
    println!("x = {x} and y = {y}");

    let c = x + y;
    println!("c = {c}");

    const THREE_HOURS_IN_SECONDS: u32 = 3 * 60 * 60;
    println!("THREE_HOURS_IN_SECONDS : {THREE_HOURS_IN_SECONDS}");

    // Constants
    // Like immutable variables, constants are values 
    // that are bound to a name and are not allowed
    // to change, 

    //but there are a few differences between constants 
    // and variables.

    // First, you aren’t allowed to use mut with constants. 
    // Constants aren’t just immutable by default—
    // they’re always immutable. You declare constants 
    // using the const keyword instead of the let keyword, 
    // and the type of the value must be annotated

    // The last difference is that constants may be set only 
    // to a constant expression, not the result of a value 
    // that could only be computed at runtime.

    // const CONST_VALUE: u32 = c * 10 ;
    // -----------------        ^ non-constant value

    // Rust’s naming
    // convention for constants is to use all uppercase with 
    // underscores between words

    // const THREE_HOURS_IN_SECONDS: u32 = 3 * 60 * 60 * 100;

    // Constants are valid for the entire time a program runs, 
    // within the scope they were declared in
}

//_____________________________________________________

fn play_with_shadowing() {
    let x = 5;
    let x = x + 1; // Shadowing In Same Scope
    println!("The Value of x : {x}");

    { //Shadowing In Different Scope i.e. Local Scope 
        let x = x * 2;
        println!("The Value of x : {x}");
    } //Shadowing Will Go 

    println!("The Value of x : {x}");

// you can declare a new variable with the same name 
// as a previous variable. Rustaceans say that the first 
// variable is shadowed by the second, which means that 
// the second variable is what the compiler will see when 
// you use the name of the variable. In effect, the second 
// variable overshadows the first, taking any uses of the 
// variable name to itself until either it itself is shadowed 
// or the scope ends. We can shadow a variable by using the 
// same variable’s name and repeating the use of the let keyword

// Shadowing is different from marking a variable as mut , 
// because we’ll get a compile-time error if we accidentally 
// try to reassign to this variable without using the let 
// keyword. By using let , we can perform a few transformations 
// on a value but have the variable be immutable after those 
// transformations have been completed.

// The other difference between mut and shadowing is that 
// because we’re effectively creating a new variable when 
// we use the let keyword again, we can change the type of 
// the value but reuse the same name. 
    let spaces = "     ";
    println!("Spaces : {spaces}");

    let spaces = spaces.len();
    println!("Spaces : {spaces}");
}

//_____________________________________________________

// Data Types
// Every value in Rust is of a certain data type, 
// which tells Rust what kind of data is being
// specified so it knows how to work with that data. 

// We’ll look at two data type subsets: scalar
// and compound.

// Scalar Types
// A scalar type represents a single value. 

// Rust has four primary scalar types: 
// integers, floating-point numbers, Booleans, 
// and characters.

// IN C Type Ranges Relationships
//      short <= int <= long <= long long

// Integer Types
// An integer is a number without a fractional component. 
// We used one integer type the u32 type. 
// This type declaration indicates that the value 
// it’s associated with should be an unsigned integer 
// (signed integer types start with i , instead of u ) 
// that takes up 32 bits ofspace.

// DESIGN PRINCIPLE
//      Errors should never pass silently.
//      Unless explicitly silenced.
//      Warning Should Be Treated As Error In Design

// Integer Types in Rust

// Assume n Is Number Of Bits
// Unsigned Integer Types
//      [  0, ( 2^n ) - 1  ]

// Signed Integer Types
//      [ -2^(n-1), ( 2^(n-1) ) - 1 ]

// Length   Signed                  Unsigned
// 8-bit    i8 = [-128, 127]        u8  = [0, 255]
// 16-bit   i16= [-32768, 32767]    u16 = [0, 65535]
// 32-bit   i32     u32 
// 64-bit   i64     u64
// 128-bit  i128    u128

// arch     isize   usize
// Hardware Is 32 Bit
// arch     isize   usize
//      usize = [  0, 2^32 - 1 ]
//      isize = [ -2^31, 2^32 - 1 ]

// IN SWIFT LANGUAGE
//      Int8, Int16, Int32, Int64
//      UInt8, UInt16, UInt32, UInt64

//      Int
//      In most cases, you don’t need to pick a specific 
//      size of integer to use in your code. 
//      Swift provides an additional integer type, Int, 
//      which has the same size as the current platform’s 
//      native word size:
//      On a 32-bit platform, Int is the same size as Int32.
//      On a 64-bit platform, Int is the same size as Int64.

//      SWIFT GUIDELINES :: [ NOTE IT"S AGAINST DEFINITION ]
//      Unless you need to work with a specific size of integer, 
//      always use Int for integer values in your code. 
//      This aids code consistency and interoperability. 
//      Even on 32-bit platforms, Int can store any value 
//      between -2,147,483,648 and 2,147,483,647, and is large 
//      enough for many integer ranges.

// RUST GUIDELINES

// Each variant can be either signed or unsigned and 
// has an explicit size. Signed and unsigned
// refer to whether it’s possible for the number to be 
// negative—in other words, whether the
// number needs to have a sign with it (signed) or whether 
// it will only ever be positive and can therefore be 
// represented without a sign (unsigned).

// IN RUST
//  Signed numbers are stored using two’s complement 
//  representation.

// Additionally, the isize and usize types depend on the 
// architecture of the computer your program is running 
// on, which is denoted in the table as “arch”: 64 bits 
// if you’re on a 64-bit architecture and 32 bits 
// if you’re on a 32-bit architecture.

// Note that number literals that can be multiple numeric 
// types allow a type suffix, such as 57u8 , 
// to designate the type.

// Integer Literals in Rust
// Number literals Example
// Decimal          98_222
// Hex              0xff
// Octal            0o77
// Binary           0b1111_0000
// Byte(u8 only)    b'A'

// Integer overflow will occur, which can result in one 
// of two behaviors. When you’re compiling in debug
// mode, Rust includes checks for integer overflow that 
// cause your program to panic at runtime if this behavior 
// occurs. Rust uses the term panicking when a program 
// exits with an error;

// When you’re compiling in release mode with the --release 
// flag, Rust does not include checks for integer overflow 
// that cause panics. Instead, if overflow occurs, Rust
// performs two’s complement wrapping.


// DESIGN PRINCIPLE
//      DRIVE CODE DESIGN DRIVEN BY TYPES DESIGN/DEFINITION


// RUST GUIDELINES FOR OVERFLOW/UNDERFLOW
// To explicitly handle the possibility of overflow, 
// you can use these families of methods provided by the 
// standard library for primitive numeric types:
// Wrap in all modes with the wrapping_* methods, 
// such as wrapping_add Return the None value 
// if there is overflow with the checked_* methods
// Return the value and a boolean indicating whether 
// there was overflow with the overflowing_* methods
// Saturate at the value’s minimum or maximum values with 
// saturating_* methods

#[allow(unused)]
fn play_with_data_types() {
    // let guess: u32 = "42".parse().expect("Not A Number");
    let _guess: u32 = "42".parse().expect("Not A Number");

    let someting = 2.0; // f64
    let someting_again: f32 = 2.0;

    // addition
    let sum = 5 + 10;
    // subtraction
    let difference = 95.5 - 4.3;
    // multiplication
    let product = 4 * 30;
    // division
    let quotient = 56.7 / 32.2;
    let floored = 2 / 3; // Results in 0
    // remainder
    let remainder = 43 % 5;

    let t = true;
    let f: bool = false; // with explicit type annotation

    let c = 'z';
    let z: char = 'ℤ'; // with explicit type annotation
    let heart_eyed_cat = '🐈';
}

// Note that we specify char literals with single quotes, 
// as opposed to string literals, which use
// double quotes. 

// Rust’s char type is four bytes in size and represents a 
// Unicode Scalar Value, which means it can represent a lot 
// more than just ASCII

// char values in Rust.
// Unicode Scalar Values range from U+0000 to U+D7FF and 
// U+E000 to U+10FFFF inclusive.

//_____________________________________________________

// Compound Types
// Compound types can group multiple values into one type. 
// Rust has two primitive compound types: tuples and arrays.

// The Tuple Type
// A tuple is a general way of grouping together a number of 
// values with a variety of types into one compound type. 
// Tuples have a fixed length: once declared, they cannot 
// grow or shrink in size.

// We create a tuple by writing a comma-separated list of values 
// inside parentheses. Each position in the tuple has a type, 
// and the types of the different values in the tuple don’t have
// to be the same. We’ve added optional type annotations

fn play_with_tuple() {
    //type `({integer}, {float}, {integer})`
    let tuple = (500, 60.80, 90);
    println!("Tuple : {} {} {}", tuple.0, tuple.1, tuple.2);
    // println!("Tuple : {tuple.0} {tuple.1} {tuple.2}");

    let mut tuple_again = (500, 60.80, 90);
    println!("Tuple : {} {} {}", tuple.0, tuple.1, tuple.2);

    // tuple_again = (500, 60.80, 90.90);
    tuple_again = (500, 60.80, 91);
    // println!("Tuple : {} {} {}", tuple.0, tuple.1, tuple.2);

    println!("Tuple : {:?} ", tuple);

}

// In Kotlin
//      Expression By Default Retuns Unit Value of Unit Type

// In Rust
    // The tuple without any values has a special name, unit. 
    // This value and its corresponding type
    // are both written () and represent an empty value or 
    // an empty return type. 

// Expressions implicitly return the unit value if they 
// don’t return any other value.

//_____________________________________________________

// Another way to have a collection of multiple values is 
// with an array. Unlike a tuple, every element of an array 
// must have the same type. Unlike arrays in some other 
// languages, arrays in Rust have a fixed length.

#[allow(unused)]
fn play_with_arrays() {
    let a = [1, 2, 3, 4, 5];

    let months = ["January", "February", "March", "April", "May", "June", "July",
"August", "September", "October", "November", "December"];

    let aa: [i32; 5] = [1, 2, 3, 4, 5];

    let aaa = [3; 5];
    // let aaa = [3, 3, 3, 3, 3];

    let first   = a[0];
    let second  = a[1];
}

//_____________________________________________________

fn play_with_arrays_indexing() {
    let a = [1, 2, 3, 4, 5];
    println!("Please enter an array index.");
    let mut index = String::new();
    
    io::stdin()
        .read_line(&mut index)
        .expect("Failed to read line");

    let index: usize = index
        .trim()
        .parse()
        .expect("Index entered was not a number");

    let element = a[index];
    println!("The value of the element at index {index} is: {element}");
}

//_____________________________________________________

fn another_function() {
    println!("Another Function");
}

fn another_function1(x: i32) {
    println!("The value of x is: {x}");
}

fn print_labeled_measurement(value: i32, unit_label: char) {
    println!("The measurement is: {value}{unit_label}");
}

fn play_with_another_function() {
    let result = another_function();
    println!("Result : {:?} ", result);

    if result == () {
        println!("Unit Found")
    }

    another_function1(100);
}

//_____________________________________________________

// Statements are instructions that perform some action and 
// do not return a value. 

// Expressions evaluate to a resulting value i.e. Return Value

fn play_with_expressions_statements() {
    let x = 10;

    // In RUST It's Not Valid
    // Because let Assignment Is A Statement
    // let yy = (let y = 10); 

    let something = 10;

    // let result = if someting { 50 } else { 100 };
    
    let result1 = if something == 10 { 50; } else { 100; };
    println!("Result1 : {:?} ", result1);
    
    let result2 = if something == 10 { 50 } else { 100 };
    println!("Result2 : {} ", result2);

//     let result3 = if something = 0 { 50 } else { 100 };
//     println!("Result2 : {} ", result3 );
// 
}

// Function : play_with_expressions_statements
// Result1 : () 
// Result2 : 50 

//_____________________________________________________
//_____________________________________________________
//_____________________________________________________

fn main() {
    println!("\nFunction : play_guess_game");
    // play_guess_game();

    println!("\nFunction : play_mutability_immutability");
    play_mutability_immutability();

    println!("\nFunction : play_with_shadowing");
    play_with_shadowing();

    println!("\nFunction : play_with_data_types");
    play_with_data_types();

    println!("\nFunction : play_with_tuple");
    play_with_tuple();

    // println!("\nFunction : play_with_arrays_indexing");
    // play_with_arrays_indexing();

    println!("\nFunction : play_with_another_function");
    play_with_another_function();

    println!("\nFunction : play_with_expressions_statements");
    play_with_expressions_statements();

    // println!("\nFunction : ");
    // println!("\nFunction : ");
    // println!("\nFunction : ");
    // println!("\nFunction : ");
}