// By default, Rust has a set of items defined in the 
// standard library that it brings into the
// scope of every program. This set is called the prelude

use std::io;
use std::cmp::Ordering;
use rand::Rng;

fn play_guess_game() {
    println!("Guess The Number!");

    let secret_number = rand::thread_rng().gen_range(1..=100);
    println!("Secret Number = {secret_number}.");    
    

// DESIGN PRINCIPLE
//      DESIGN TOWARDS IMMUTABILITY RATHER THAN MUTABILITY

// Type Idea
//      1. Type Inferrencing From R.H.S
//      2. Type Binding To LHS ( Inferred Type From RHS )
//      3. Type Inferrencing and Binding Happens At Compile Time

// The :: syntax in the ::new line indicates that new is an 
// associated function of the String type. An associated function 
// is a function that’s implemented on a type, in this case String .
// This new function creates a new, empty string. 

    // let mut guess = String::new();
    // io::stdin().read_line( &guess ).expect("Failed To Read Line");

// read_line puts whatever the user enters into the string 
// we pass to it, but it also returns a Result value. 
// Result is an enumeration, often called an enum, which is
// a type that can be in one of multiple possible states. 
// We call each possible state a variant.

// Result 's variants are Ok and Err . The Ok variant indicates 
// the operation was successful, and inside Ok is the 
// successfully generated value. 
// The Err variant means the operation failed, 
// and Err contains information about how or why the operation failed.

// Values of the Result type, like values of any type, 
// have methods defined on them. An instance of Result has an 
// expect method that you can call. If this instance of Result is an
// Err value, expect will cause the program to crash and display 
// the message that you passed as an argument to expect .

// If this instance of Result is an Ok value, expect will 
// take the return value that Ok is holding and return just
// that value to you so you can use it

    // let something = io::stdin().read_line( &mut guess );
     // ^^^^^^^^^ help: if this is intentional, prefix it with 
     //           an underscore: `_something`
    // let _something = io::stdin().read_line( &mut guess );
    // let _ = io::stdin().read_line( &mut guess );


    // let guess_again: u32 = guess.trim()
    //                         .parse()
    //                         .expect("Please Try A Number");

    
    loop {
        println!("Please input your guess.");

        let mut guess = String::new();

        io::stdin()
            // .read_line( &guess );
            // ---------  ^^^^^^ types differ in mutability
            .read_line( &mut guess ) // & Is Giving Reference/Address
            .expect("Failed To Read Line");

        // guess identifier Shadows Previous Definition
        // let guess: u32 = guess.trim()
        //                       .parse()
        //                       .expect("Please Try A Number");
        let guess: u32 = match guess.trim().parse() {
            Ok(number)  => number,
            Err(_)      => continue,
        };
  
        // match guess_again.cmp( &secret_number ) {
        match guess.cmp( &secret_number ) {
            Ordering::Less      => println!("Too Small!"),
            Ordering::Greater   => println!("Too Big!"),
            Ordering::Equal     => {
                println!("You Win!");
                break;
            }
        }

        println!("Your Guess: {guess}");
    }
}

fn play_mutability_immutability() {
    let apples = 55;
    // error[E0384]: cannot assign twice to immutable variable `apples`
    // apples = 555;
    println!("Apples: {apples}");

    let mut oranges = 100;
    println!("Oranges: {oranges}");
    oranges = 111;
    println!("Oranges: {oranges}");

    let x = 44;
    let y = 55;    

    println!("x = {} and y = {}", x, y );
    println!("x = {x} and y = {y}");

    let c = x + y;
    println!("c = {c}");
}

//_____________________________________________________

// Cargo understands Semantic
// Versioning (sometimes called SemVer), which is a 
// standard for writing version numbers. The
// number 0.8.3 is actually shorthand for ^0.8.3 , 
// which means any version that is at least
// 0.8.3 but below 0.9.0 .

// Cargo considers these versions to have public APIs 
// compatible with version 0.8.3 , and this
// specification ensures you’ll get the latest patch 
// release that will still compile with the code i

//_____________________________________________________
//_____________________________________________________
//_____________________________________________________
//_____________________________________________________

fn main() {
    println!("\nFunction : ");
    play_guess_game();

    println!("\nFunction : ");
    play_mutability_immutability();

    // println!("\nFunction : ");
    // println!("\nFunction : ");
    // println!("\nFunction : ");
    // println!("\nFunction : ");
    // println!("\nFunction : ");
    // println!("\nFunction : ");
}