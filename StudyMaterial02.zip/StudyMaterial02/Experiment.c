#include <stdio.h>
#include <limits.h>
#include <stdlib.h>

// Pre Processor Directives
#define PI 3.14
#define i8 signed char
#define u8 unsigned char

//____________________________________________

void doChange(int *demon) {
	*demon = 999;
}

void playWithConst() {
	int something = 10;

	printf("\n %d", something);
	something = 100;
	printf("\n %d", something);

	// Programmer Intention To Achieve Immutability
	const int somethingAgain = 9;
	printf("\n %d", somethingAgain);
	// somethingAgain = 99;

	int *demon = &somethingAgain;
	*demon = 99;
	printf("\n %d", somethingAgain);

	doChange( &somethingAgain );
	printf("\n %d", somethingAgain);
}

//____________________________________________

void playWithMacros() {
	float radius = 10.0;
	float area = PI * radius * radius;

	printf("\nArea : %f", area); 
}

//____________________________________________


void playWithCharType() {
	// signed char ch = 'A';
	char ch = 'A';

	for ( char i = ch ; i < 128 ; i++ ) {
		printf(" %d %c :: ", i, i );
	}
}

//____________________________________________

// GOOD DESIGN: TYPE DEFINITION DRIVEN DESIGN
// TYPE SAFE CODE
int summation(signed int x, signed int y) {
	  signed int result;
	  // Type Definition
	  if (((y > 0 ) && (x > (INT_MAX - y))) ||
	      ((y < 0) && (x < (INT_MIN - y)))) {
	  	//printf("\nCan't Calculate Sum");
	  	exit(1); // Code Crash, Exception Thrown
	  } else {
	    result = x + y;
	  	return result;
	  }
	  /* ... */
}

//____________________________________________

void playWithFloatType() {
	float f1 = 3.0;
	float f2 = 3.0;

	int something = 3;
	if ( something == f1 ) {
		printf("\nEqual Value");
	} else {
		printf("\nUnEqual Value");
	}

	// if ( f1 - f2 < epsilon )
	if ( f1 == f2 ) {
		printf("\nEqual Value");
	} else {
		printf("\nUnEqual Value");
	}

	float ff = 90908054090495045.909090;
	// 9.090806

	// int q = 10, d = 0;
	// int dd = q / d;
	// printf("\n%d", dd);	

	float fff = 10.0/0.0;
	printf("\n%f", fff);
}

//____________________________________________

void play_with_array() {
	int count = 5;
	int a[5] = {10, 20, 30, 40, 50 };

	int i = -10;
	// int i = sum(a, b);
	for (	; i < 10 ; i++ ) {
		printf(" %d ", a[i] );
	}
	// a[-10];
}

//____________________________________________

void play_with_if_else() {
	int something = -10;

	if (something) {
		printf("Something Happened!");
	} else {
		printf("What The Hell This Is...");
	}

	int result = 10;

	// CODE 01
	if (something) {
		result = 50;
	} else {
		result = 100;
	}

	printf("\nResult : %d", result);
	
	// CODE 02
	result = ( something ) ? 50 : 100;
	printf("\nResult : %d", result);

	int yy = y = 10;

	if ( something = 0 ) {
		printf("Something Happened!");
	} else {
		printf("What The Hell This Is...");
	}

	// if ( 0 = something  ) {
	// 	printf("Something Happened!");
	// } else {
	// 	printf("What The Hell This Is...");
	// }
}

//____________________________________________
//____________________________________________
//____________________________________________
//____________________________________________

void main() {
	printf("\n\nFunction : playWithConst");
	playWithConst();

	printf("\n\nFunction : playWithMacros");
	playWithMacros();

	// printf("\n\nFunction : playWithCharType");
	// playWithCharType();

	printf("\n\nFunction : playWithFloatType");
	playWithFloatType();

	printf("\n\nFunction : play_with_array");
	play_with_array();

	printf("\n\nFunction : play_with_if_else");
	play_with_if_else();

	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
}
